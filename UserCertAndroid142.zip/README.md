# UserCertAndroid14
Magisk module to install user certificate in Android 14 (modify from [adguardcert](https://github.com/AdguardTeam/adguardcert))
Remove so
# Usage
1. Install module in Magisk Manager
2. Install CA to device
3. Reboot device

# Refer